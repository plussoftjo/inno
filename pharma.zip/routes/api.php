<?php

use Illuminate\Http\Request;

Route::post('/active/store','activeController@store');
Route::post('/active/search','activeController@search');


Route::post('/load/store','loadController@store');