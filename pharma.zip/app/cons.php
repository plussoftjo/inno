<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cons extends Model
{
     protected $fillable = [
        'active', 'couns', 'warn','cont'
    ];
}
