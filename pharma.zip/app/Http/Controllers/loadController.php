<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\load;
class loadController extends Controller
{
    public function store(Request $req) 
    {
    	return load::create([
    		'active' => $req->active,
    		'code' => $req->code,
    		'tradeName' => $req->tradeName,
    		'paking' => $req->paking,
    		'focus' => $req->focus,
    		'pPrice' => $req->pPrice,
    		'ppPrice' => $req->ppPrice,
    	]);
    }
}
