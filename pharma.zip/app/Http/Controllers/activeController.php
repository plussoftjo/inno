<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cons;
use App\load;
class activeController extends Controller
{
    public function store(Request $req)
    {
    	return cons::create([
    		'active' => $req->active,
    		'couns' => $req->couns,
    		'warn'=> $req->warn,
    		'cont' => $req->cont
    	]);
    }

    public function search(Request $req)
    {
    	return response()->json(cons::where('active','like','%'.$req->search.'%')->take(4)->get());
    }
}
