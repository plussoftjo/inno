<template>
	<div class="dashboard">
		dashboard
	</div>
</template>
<script>
	export default {
		
	}
</script>