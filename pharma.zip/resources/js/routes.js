import dashboard from './components/app/dashboard.vue'
import newPharm from './components/app/newPharm'
import submit from './components/app/submit'
export const routes = [
	{
		path:'/',
		name:'dashboard',
		component:dashboard
	},
	{
		path:'/submit',
		name:'Submit',
		component:submit
	},
	{
		path:'/newPharm',
		name:'New',
		component:newPharm
	}
]